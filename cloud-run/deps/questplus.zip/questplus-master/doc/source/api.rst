API  Documentation
******************

.. toctree::
   :maxdepth: 2

    QuestPlus <qp.rst>
    Psychometric functions <psychometric_function.rst>
    Utils <utils.rst>
