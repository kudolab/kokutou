`questplus`, a simple QUEST+ implementation in Python
=====================================================

.. toctree::
   :maxdepth: 3

    Requirements & installation <installation.md>
    Usage example <usage_example.md>

    API <api.rst>
